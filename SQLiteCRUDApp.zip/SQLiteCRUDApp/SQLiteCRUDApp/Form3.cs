﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SQLiteCRUDApp
{
    public partial class Form3 : Form
    {
        private string cs = "URI=file:./neoStockDB.db";

        private Form1 _form1;
        public Form3(Form1 form1)
        {
            InitializeComponent();
            SetupAutoComplete();
            _form1 = form1;

        }
        private void LoadData()
        {
            using var con = new SQLiteConnection(cs);
            con.Open();

            // string stm = "SELECT * FROM stockArticulo";
            //string stm = "SELECT a.Nombre, s.IdStock, s.Cantidad, s.FechaVencimiento, m.FechaMovimiento FROM Articulos a JOIN StockArticulo s ON a.IdArticulo = s.CodeArticulo JOIN MovimientoStock m ON a.IdArticulo = m.CodeArticulo";
            string stm = "SELECT a.Nombre, s.IdStock, s.Cantidad, s.FechaVencimiento FROM Articulos a JOIN StockArticulo s ON a.IdArticulo = s.CodeArticulo";
            using var cmd = new SQLiteCommand(stm, con);
            using SQLiteDataReader rdr = cmd.ExecuteReader();

            var dt = new DataTable();
            dt.Load(rdr);
            dataGridView1.DataSource = dt;
        }

        private void SetupAutoComplete()
        {
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            using (var con = new SQLiteConnection(cs))
            {
                con.Open();
                string stm = "SELECT Nombre FROM Articulos";
                using (var cmd = new SQLiteCommand(stm, con))
                {
                    using (SQLiteDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            autoCompleteCollection.Add(rdr.GetString(0));
                        }
                    }
                }
            }

            txtBuscarArticulo.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtBuscarArticulo.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtBuscarArticulo.AutoCompleteCustomSource = autoCompleteCollection;
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnBackForm1_Click(object sender, EventArgs e)
        {
            _form1.Show();
            this.Close();
        }

        private void btnStockAdd_Click(object sender, EventArgs e)
        {
            // Verificar si los campos están vacíos
            if (string.IsNullOrWhiteSpace(txtBuscarArticulo.Text))
            {
                MessageBox.Show("Por favor, completa el campo NOMBRE para agregar a la lista.");
                return;
            }

            string nombre = txtBuscarArticulo.Text;
            int cantidad = (int)numericUpDownCantidad.Value;
            DateTime fechaVencimiento = dateTimePickerFechaVencimiento.Value;
            DateTime fechaMovimiento = dateTimePickerMovimiento.Value;
            string tipoMovimiento = txtBuscarArticulo.Text;

            InsertStock(nombre, cantidad, fechaVencimiento, fechaMovimiento, tipoMovimiento);
        }
        private void InsertStock(string nombre, int cantidad, DateTime fechaVencimiento, DateTime fechaMovimiento, string tipoMovimiento)
        {
            using (var con = new SQLiteConnection(cs))
            {
                con.Open();

                // Verificar si el artículo ya existe
                string selectArticuloStm = "SELECT IdArticulo FROM Articulos WHERE Nombre = @nombre";
                int idArticulo = 0;

                using (var cmd = new SQLiteCommand(selectArticuloStm, con))
                {
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    using (SQLiteDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr.Read())
                        {
                            idArticulo = rdr.GetInt32(0);
                        }
                    }
                }

                // Si el artículo no existe, insertarlo
                if (idArticulo == 0)
                {
                    MessageBox.Show("El Articulo NO existe!.");
                    return;
                }


                // Insertar el stock en la tabla StockArticulo
                string insertStockStm = "INSERT INTO StockArticulo (CodeArticulo, Cantidad, FechaVencimiento) VALUES (@CodeArticulo, @cantidad, @fechaVencimiento)";
                using (var cmd = new SQLiteCommand(insertStockStm, con))
                {
                    cmd.Parameters.AddWithValue("@CodeArticulo", idArticulo);
                    cmd.Parameters.AddWithValue("@cantidad", cantidad);
                    cmd.Parameters.AddWithValue("@fechaVencimiento", fechaVencimiento);
                    cmd.ExecuteNonQuery();
                }

                // Insertar en los movimientos de la tabla MovimientoStock
              /*  string insertMovimientosStm = "INSERT INTO MovimientoStock (CodeArticulo, Cantidad, FechaMovimiento, TipoMovimiento) VALUES (@CodeArticulo, @Cantidad, @fechaMovimiento, @TipoMovimiento)";
                using (var cmd = new SQLiteCommand(insertMovimientosStm, con))
                {
                    cmd.Parameters.AddWithValue("@CodeArticulo", idArticulo);
                    cmd.Parameters.AddWithValue("@cantidad", cantidad);
                    cmd.Parameters.AddWithValue("@fechaMovimiento", fechaMovimiento);
                    cmd.Parameters.AddWithValue("@TipoMovimiento", tipoMovimiento);
                    cmd.ExecuteNonQuery();
                }*/
            }

            MessageBox.Show("Stock agregado exitosamente.");
            LoadData();
        }

        private void btnStockDelete_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            LoadData(); // Carga los datos cuando el formulario se carga
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int idArticulo = Convert.ToInt32(selectedRow.Cells["ID"].Value); //IdArticulo

                using (var con = new SQLiteConnection(cs))
                {
                    con.Open();
                    string stm = "DELETE FROM StockArticulo WHERE IdStock = @id";
                    using (var cmd = new SQLiteCommand(stm, con))
                    {
                        cmd.Parameters.AddWithValue("@id", idArticulo);
                        cmd.ExecuteNonQuery();
                    }
                }

                LoadData();
                MessageBox.Show("Artículo borrado exitosamente.");
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila para borrar.");
            }

        }



        private void dataGridView1_CellFormatting_1(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "FechaVencimiento")
            {
         
                DateTime fechaVencimiento = Convert.ToDateTime(e.Value);
                if (fechaVencimiento.Date <= DateTime.Now.Date)
                {
                    e.CellStyle.BackColor = Color.Red;
                    e.CellStyle.ForeColor = Color.White;
                }
                else if (fechaVencimiento.Date <=DateTime.Now.Date.AddDays(7))
                {
                    e.CellStyle.BackColor = Color.Yellow;
                    e.CellStyle.ForeColor = Color.Black;
                }

             
            }
        }
    }
}
