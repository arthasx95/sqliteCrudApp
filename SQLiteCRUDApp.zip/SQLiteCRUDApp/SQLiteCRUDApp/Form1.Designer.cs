﻿namespace SQLiteCRUDApp
{
    partial class Form1
    {

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRead = new Button();
            btnForm2 = new Button();
            btnStockForm3 = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnRead
            // 
            btnRead.Location = new Point(731, 14);
            btnRead.Margin = new Padding(4);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(54, 35);
            btnRead.TabIndex = 3;
            btnRead.Text = "...";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click_1;
            // 
            // btnForm2
            // 
            btnForm2.Location = new Point(295, 284);
            btnForm2.Margin = new Padding(4);
            btnForm2.Name = "btnForm2";
            btnForm2.Size = new Size(220, 64);
            btnForm2.TabIndex = 11;
            btnForm2.Text = "Nuevo producto";
            btnForm2.UseVisualStyleBackColor = true;
            btnForm2.Click += btnForm2_Click;
            // 
            // btnStockForm3
            // 
            btnStockForm3.Location = new Point(295, 194);
            btnStockForm3.Margin = new Padding(4);
            btnStockForm3.Name = "btnStockForm3";
            btnStockForm3.Size = new Size(220, 64);
            btnStockForm3.TabIndex = 22;
            btnStockForm3.Text = "Stock";
            btnStockForm3.UseVisualStyleBackColor = true;
            btnStockForm3.Click += btnStockForm3_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(367, 112);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(71, 32);
            label1.TabIndex = 23;
            label1.Text = "Menu";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(800, 510);
            Controls.Add(label1);
            Controls.Add(btnStockForm3);
            Controls.Add(btnForm2);
            Controls.Add(btnRead);
            Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "StockControlApp";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnRead;
        private Button btnForm2;
        private Button btnStockForm3;
        private Label label1;
    }
}
