﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLiteCRUDApp
{
    public partial class Form2 : Form
    {
        private string cs = "URI=file:./neoStockDB.db";

        private Form1 _form1;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            dataGridView1.AutoGenerateColumns = false;
            _form1 = form1;

        }
        private void LoadData()
        {
            using var con = new SQLiteConnection(cs);
            con.Open();

            string stm = "SELECT IdArticulo, Nombre, Descripcion, Categoria, Precio FROM Articulos";
            using var cmd = new SQLiteCommand(stm, con);
            using SQLiteDataReader rdr = cmd.ExecuteReader();

            var dt = new DataTable();
            dt.Load(rdr);
            dataGridView1.DataSource = dt;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData(); // Carga los datos cuando el formulario se carga

            comboBox1.Items.Add("Bebidas");
            comboBox1.Items.Add("Lacteos");
            comboBox1.Items.Add("Snacks");
            comboBox1.Items.Add("Golosinas");
            comboBox1.Items.Add("Galletitas");
            comboBox1.Items.Add("Higiene");
            comboBox1.Items.Add("Otros");
        }

        private void btnAgregarStock_Click(object sender, EventArgs e)
        {
            // Verificar si los campos están vacíos
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(comboBox1.Text))
            {
                MessageBox.Show("Por favor, completa los campos NOMBRE y CATEGORIA para agregar a la lista.");
                return;
            }

            using var con = new SQLiteConnection(cs);
            con.Open();

            using var cmd = new SQLiteCommand(con);

            cmd.CommandText = "INSERT INTO articulos(Nombre, Descripcion, Categoria, Precio) VALUES(@nombre, @descripcion, @categoria, @precio)";
            cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
            cmd.Parameters.AddWithValue("@descripcion", txtDescripcion.Text);
            cmd.Parameters.AddWithValue("@categoria", comboBox1.Text);
            cmd.Parameters.AddWithValue("@precio", txtPrecio.Text);
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Nuevo articulo agregado a la lista.");
            LoadData();
        }

        private void textMarca_TextChanged(object sender, EventArgs e)
        {

        }

       /* private void btnDeleteArt_Click(object sender, EventArgs e)
        {
            // Verificar si los campos están vacíos
            if (string.IsNullOrWhiteSpace(txtDeleteArt.Text))
            {
                MessageBox.Show("Por favor, completa el campo de ID.");
                return;
            }

            using var con = new SQLiteConnection(cs);
            con.Open();

            using var cmd = new SQLiteCommand(con);

            //  cmd.CommandText = "DELETE FROM Users WHERE Name = @name";
            // cmd.Parameters.AddWithValue("@name", txtName.Text);
            cmd.CommandText = "DELETE FROM articulos WHERE IdArticulo = @Id";
            cmd.Parameters.AddWithValue("@Id", int.Parse(txtDeleteArt.Text));
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Datos ELIMINADOS.");
            LoadData();
        }*/

        private void btnBackForm1_Click(object sender, EventArgs e)
        {

            _form1.Show();
            this.Close();
        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si el carácter no es un número y no es la tecla de retroceso (Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Si no es un número, cancelar el evento
                e.Handled = true;
            }
        }

        private void txtDeleteArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si el carácter no es un número y no es la tecla de retroceso (Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                // Si no es un número, cancelar el evento
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int idArticulo = Convert.ToInt32(selectedRow.Cells["ID"].Value); //IdArticulo

                using (var con = new SQLiteConnection(cs))
                {
                    con.Open();
                    string stm = "DELETE FROM Articulos WHERE IdArticulo = @id";
                    using (var cmd = new SQLiteCommand(stm, con))
                    {
                        cmd.Parameters.AddWithValue("@id", idArticulo);
                        cmd.ExecuteNonQuery();
                    }
                }

                LoadData();
                MessageBox.Show("Artículo borrado exitosamente.");
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una fila para borrar.");
            }
        }


    }
}

