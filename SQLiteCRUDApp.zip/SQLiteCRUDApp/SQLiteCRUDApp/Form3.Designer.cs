﻿namespace SQLiteCRUDApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStockAdd = new Button();
            btnBackForm1 = new Button();
            dataGridView1 = new DataGridView();
            txtBuscarArticulo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            numericUpDownCantidad = new NumericUpDown();
            dateTimePickerFechaVencimiento = new DateTimePicker();
            label3 = new Label();
            btnDelete = new Button();
            label4 = new Label();
            dateTimePickerMovimiento = new DateTimePicker();
            label5 = new Label();
            radioButtonSalida = new RadioButton();
            radioButtonEntrada = new RadioButton();
            ID = new DataGridViewTextBoxColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Cantidad = new DataGridViewTextBoxColumn();
            FechaVencimiento = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownCantidad).BeginInit();
            SuspendLayout();
            // 
            // btnStockAdd
            // 
            btnStockAdd.Location = new Point(726, 393);
            btnStockAdd.Name = "btnStockAdd";
            btnStockAdd.Size = new Size(250, 40);
            btnStockAdd.TabIndex = 31;
            btnStockAdd.Text = "Agregar";
            btnStockAdd.UseVisualStyleBackColor = true;
            btnStockAdd.Click += btnStockAdd_Click;
            // 
            // btnBackForm1
            // 
            btnBackForm1.Location = new Point(64, 449);
            btnBackForm1.Name = "btnBackForm1";
            btnBackForm1.Size = new Size(80, 40);
            btnBackForm1.TabIndex = 35;
            btnBackForm1.Text = "Volver";
            btnBackForm1.UseVisualStyleBackColor = true;
            btnBackForm1.Click += btnBackForm1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ID, Nombre, Cantidad, FechaVencimiento });
            dataGridView1.Location = new Point(64, 32);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(595, 401);
            dataGridView1.TabIndex = 36;
            dataGridView1.CellFormatting += dataGridView1_CellFormatting_1;
            // 
            // txtBuscarArticulo
            // 
            txtBuscarArticulo.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtBuscarArticulo.Location = new Point(725, 55);
            txtBuscarArticulo.Name = "txtBuscarArticulo";
            txtBuscarArticulo.Size = new Size(251, 27);
            txtBuscarArticulo.TabIndex = 37;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(725, 32);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 38;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(725, 99);
            label2.Name = "label2";
            label2.Size = new Size(69, 20);
            label2.TabIndex = 39;
            label2.Text = "Cantidad";
            // 
            // numericUpDownCantidad
            // 
            numericUpDownCantidad.Location = new Point(725, 122);
            numericUpDownCantidad.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numericUpDownCantidad.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownCantidad.Name = "numericUpDownCantidad";
            numericUpDownCantidad.Size = new Size(150, 27);
            numericUpDownCantidad.TabIndex = 40;
            numericUpDownCantidad.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // dateTimePickerFechaVencimiento
            // 
            dateTimePickerFechaVencimiento.Location = new Point(725, 197);
            dateTimePickerFechaVencimiento.Name = "dateTimePickerFechaVencimiento";
            dateTimePickerFechaVencimiento.Size = new Size(250, 27);
            dateTimePickerFechaVencimiento.TabIndex = 41;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(725, 174);
            label3.Name = "label3";
            label3.Size = new Size(153, 20);
            label3.TabIndex = 42;
            label3.Text = "Fecha de vencimiento";
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(571, 449);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(88, 40);
            btnDelete.TabIndex = 43;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(726, 245);
            label4.Name = "label4";
            label4.Size = new Size(121, 20);
            label4.TabIndex = 44;
            label4.Text = "Fecha de ingreso";
            // 
            // dateTimePickerMovimiento
            // 
            dateTimePickerMovimiento.Enabled = false;
            dateTimePickerMovimiento.Location = new Point(726, 268);
            dateTimePickerMovimiento.Name = "dateTimePickerMovimiento";
            dateTimePickerMovimiento.Size = new Size(250, 27);
            dateTimePickerMovimiento.TabIndex = 45;
            dateTimePickerMovimiento.Value = new DateTime(2024, 8, 7, 9, 5, 23, 0);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(726, 310);
            label5.Name = "label5";
            label5.Size = new Size(123, 20);
            label5.TabIndex = 46;
            label5.Text = "Tipo movimiento";
            // 
            // radioButtonSalida
            // 
            radioButtonSalida.AutoSize = true;
            radioButtonSalida.Location = new Point(839, 344);
            radioButtonSalida.Name = "radioButtonSalida";
            radioButtonSalida.Size = new Size(71, 24);
            radioButtonSalida.TabIndex = 48;
            radioButtonSalida.TabStop = true;
            radioButtonSalida.Text = "Salida";
            radioButtonSalida.UseVisualStyleBackColor = true;
            // 
            // radioButtonEntrada
            // 
            radioButtonEntrada.AutoSize = true;
            radioButtonEntrada.Checked = true;
            radioButtonEntrada.Location = new Point(730, 344);
            radioButtonEntrada.Name = "radioButtonEntrada";
            radioButtonEntrada.Size = new Size(81, 24);
            radioButtonEntrada.TabIndex = 47;
            radioButtonEntrada.TabStop = true;
            radioButtonEntrada.Text = "Entrada";
            radioButtonEntrada.UseVisualStyleBackColor = true;
            // 
            // ID
            // 
            ID.DataPropertyName = "IdStock";
            ID.HeaderText = "ID";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.ReadOnly = true;
            ID.Visible = false;
            ID.Width = 125;
            // 
            // Nombre
            // 
            Nombre.DataPropertyName = "Nombre";
            Nombre.HeaderText = "Nombre";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.ReadOnly = true;
            Nombre.Width = 264;
            // 
            // Cantidad
            // 
            Cantidad.DataPropertyName = "Cantidad";
            Cantidad.HeaderText = "Cantidad";
            Cantidad.MinimumWidth = 6;
            Cantidad.Name = "Cantidad";
            Cantidad.ReadOnly = true;
            Cantidad.Width = 120;
            // 
            // FechaVencimiento
            // 
            FechaVencimiento.DataPropertyName = "FechaVencimiento";
            FechaVencimiento.HeaderText = "F.Vencimiento";
            FechaVencimiento.MinimumWidth = 6;
            FechaVencimiento.Name = "FechaVencimiento";
            FechaVencimiento.ReadOnly = true;
            FechaVencimiento.Width = 140;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.OliveDrab;
            ClientSize = new Size(1028, 514);
            Controls.Add(radioButtonSalida);
            Controls.Add(radioButtonEntrada);
            Controls.Add(label5);
            Controls.Add(dateTimePickerMovimiento);
            Controls.Add(label4);
            Controls.Add(btnDelete);
            Controls.Add(label3);
            Controls.Add(dateTimePickerFechaVencimiento);
            Controls.Add(numericUpDownCantidad);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtBuscarArticulo);
            Controls.Add(dataGridView1);
            Controls.Add(btnBackForm1);
            Controls.Add(btnStockAdd);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Stock Total";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownCantidad).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnStockAdd;
        private Button btnBackForm1;
        private DataGridView dataGridView1;
        private TextBox txtBuscarArticulo;
        private Label label1;
        private Label label2;
        private NumericUpDown numericUpDownCantidad;
        private DateTimePicker dateTimePickerFechaVencimiento;
        private Label label3;
        private Button btnDelete;
        private Label label4;
        private DateTimePicker dateTimePickerMovimiento;
        private Label label5;
        private RadioButton radioButtonSalida;
        private RadioButton radioButtonEntrada;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Cantidad;
        private DataGridViewTextBoxColumn FechaVencimiento;
    }
}