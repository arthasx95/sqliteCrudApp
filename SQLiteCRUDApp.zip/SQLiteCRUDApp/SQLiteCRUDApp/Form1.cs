using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SQLiteCRUDApp
{
    public partial class Form1 : Form
    {
        private string cs = "URI=file:./neoStockDB.db";

        public Form1()
        {
            InitializeComponent();
            // CreateDatabaseAndTable();
        }

        private void CreateDatabaseAndTable()
        {
            try
            {
                using var con = new SQLiteConnection(cs);
                con.Open();
                MessageBox.Show("Conexi�n a la base de datos abierta.");

                using var cmd = new SQLiteCommand(con);

                cmd.CommandText = "DROP TABLE IF EXISTS Users";
                cmd.ExecuteNonQuery();

                cmd.CommandText = @"CREATE TABLE Users(Id INTEGER PRIMARY KEY,
                                Name TEXT, Age INTEGER)";
                cmd.ExecuteNonQuery();

                MessageBox.Show("Tabla creada.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear la tabla: {ex.Message}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData(); // Carga los datos cuando el formulario se carga
        }

        private void LoadData()
        {
            using var con = new SQLiteConnection(cs);
            con.Open();

            string stm = "SELECT * FROM stockArticulo";
            using var cmd = new SQLiteCommand(stm, con);
            using SQLiteDataReader rdr = cmd.ExecuteReader();

            var dt = new DataTable();
            dt.Load(rdr);
            //  dataGridView1.DataSource = dt;
        }
        private void btnRead_Click_1(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Verificar si los campos est�n vac�os
            /* if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAge.Text))
             {
                 MessageBox.Show("Por favor, completa ambos campos antes de ACTUALIZAR.");
                 return;
             }*/

            using var con = new SQLiteConnection(cs);
            con.Open();

            using var cmd = new SQLiteCommand(con);


            //cmd.CommandText = "UPDATE Users SET Age = @age WHERE Name = @name";
            //cmd.Parameters.AddWithValue("@name", txtName.Text);
            //cmd.Parameters.AddWithValue("@age", int.Parse(txtAge.Text));
            cmd.CommandText = "UPDATE Users SET Name = @name, Age = @age WHERE Id = @Id";
            //cmd.Parameters.AddWithValue("@name", txtName.Text);
            //cmd.Parameters.AddWithValue("@age", int.Parse(txtAge.Text));
            //cmd.Parameters.AddWithValue("@Id", int.Parse(textBox_id.Text));
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Datos actualizados.");
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Verificar si los campos est�n vac�os
            /* if (string.IsNullOrWhiteSpace(textBox_id.Text))
             {
                 MessageBox.Show("Por favor, completa el campo de ID.");
                 return;
             }*/

            using var con = new SQLiteConnection(cs);
            con.Open();

            using var cmd = new SQLiteCommand(con);

            //  cmd.CommandText = "DELETE FROM Users WHERE Name = @name";
            // cmd.Parameters.AddWithValue("@name", txtName.Text);
            cmd.CommandText = "DELETE FROM Users WHERE Id = @Id";
            //cmd.Parameters.AddWithValue("@Id", int.Parse(textBox_id.Text));
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Datos eliminados.");
            LoadData();
        }



        /* private void btnCreate_Click_1(object sender, EventArgs e)
         {
             // Verificar si los campos est�n vac�os
             if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(numericUpDown1.Text))
             {
                 MessageBox.Show("Por favor, completa ambos campos antes de CREAR.");
                 return;
             }

             using var con = new SQLiteConnection(cs);
             con.Open();

             using var cmd = new SQLiteCommand(con);

             cmd.CommandText = "INSERT INTO Users(Name, Age) VALUES(@name, @age)";
             cmd.Parameters.AddWithValue("@name", txtName.Text);
             cmd.Parameters.AddWithValue("@age", int.Parse(numericUpDown1.Text));
             cmd.Prepare();
             cmd.ExecuteNonQuery();

             MessageBox.Show("Datos insertados.");
             LoadData();
         }
        
        


         private void label1_Click(object sender, EventArgs e)
         {

         }

         private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
         {
             // Verificar si el car�cter no es un n�mero y no es la tecla de retroceso (Backspace)
             if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
             {
                 // Si no es un n�mero, cancelar el evento
                 e.Handled = true;
             }
         }

         private void textBox_id_KeyPress(object sender, KeyPressEventArgs e)
         {
             // Verificar si el car�cter no es un n�mero y no es la tecla de retroceso (Backspace)
             if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
             {
                 // Si no es un n�mero, cancelar el evento
                 e.Handled = true;
             }
         }

         private void label2_Click(object sender, EventArgs e)
         {

         }

         private void label3_Click(object sender, EventArgs e)
         {

         }
        */
        private void btnForm2_Click(object sender, EventArgs e)
        {
            // Crear una instancia del nuevo formulario
            Form2 form2 = new Form2(this);

            // Mostrar el nuevo formulario
            form2.Show();

            this.Hide();
        }

        private void btnStockForm3_Click_1(object sender, EventArgs e)
        {
            // Crear una instancia del nuevo formulario
            Form3 form3 = new Form3(this);

            // Mostrar el nuevo formulario
            form3.Show();

            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}